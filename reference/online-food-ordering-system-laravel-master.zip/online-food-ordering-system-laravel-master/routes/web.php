<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','Food_CategoriesController@showProducts' );

Route::resource('employees','EmployeesController');
Route::resource('food_categories','Food_CategoriesController');
Route::resource('food_products','Food_ProductsController');
Route::resource('food_ingredients','Food_IngredientsController');
Route::resource('food_sizes','Food_SizesController');


Route::post('/getProduct','Food_ProductsController@getProduct');
Route::post("/addToCart","OrdersController@addToCart");

Route::post("/cartQuantityAdd","OrdersController@cartQuantityAdd");
Route::post("/cartQuantityRemove","OrdersController@cartQuantityRemove");
Route::post("/cartItems","OrdersController@cartItems");



Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

