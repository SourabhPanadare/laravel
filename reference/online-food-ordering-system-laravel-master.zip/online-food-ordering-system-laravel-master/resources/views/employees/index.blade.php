@extends('layouts.template')

@section('content')

    <!-- "-->

        <div class="row col-md-10" style="background-color: white; margin-left:4px">
            <h2>All Employees</h2>
            <div style="overflow-x: auto">
            <table class="table" style="border:2px solid gainsboro;">
                <thead>
                <tr  style="background-color: #E4EDDB">
                    <th>Name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Bank Account No</th><th></th>
                </tr>
                </thead>
                <tbody>
                @foreach($employees as $employee)
                    <tr>
                        <td>{{$employee->firstname}} {{$employee->lastname}}</td>
                        <td>{{$employee->address}} {{$employee->postal_code}}</td>
                        <td>{{$employee->phone}}</td>
                        <td>{{$employee->email}}</td>
                        <td>{{$employee->bank_account}}</td>
                        <td><a href="/employees/{{$employee->id}}/edit"><button class="btn btn-info " value="Edit">Edit <i class="fa fa-edit"></i></button></a></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
                {{ $employees->links() }}
            </div>
        </div>
        <div class="col-sm-2 col-md-2 col-lg-2 pull-right" >
            <div class="sidebar-module">
                <h4>Actions</h4>
                <ol class="list-unstyled">
                    <li><a href="/employees/create"><i class="fa fa-user" aria-hidden="true"></i> Add new employee</a></li>
                </ol>
            </div>
        </div>



@endsection