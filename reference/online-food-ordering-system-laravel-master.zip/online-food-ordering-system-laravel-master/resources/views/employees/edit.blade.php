@extends('layouts.template')

@section('content')
    <div class="row col-md-9 col-lg-9 col-sm-9  " style="background: white;">
        <h2>Add new Employee</h2>

        <!-- Example row of columns -->
        <div class="row  col-md-12 col-lg-12 col-sm-12" >

            <form method="post" action="{{ route('employees.update') }}">
                {{ csrf_field() }}
                <div class="form-group">
                    <label for="ID-card">Firstname<span class="required">*</span></label>
                    <input   placeholder="firstname"
                             id="firstname"
                             required
                             name="firstname"
                             spellcheck="false"
                             class="form-control"
                             value="{{ old('firstname') }}"
                    />
                    @if ($errors->get('firstname'))
                        <div class="alert alert-dismissable alert-danger">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <strong>{{ $errors->first('firstname') }}</strong>

                        </div>
                    @endif
                </div>

                <div class="form-group">
                    <label for="ID-card">Lastname<span class="required">*</span></label>
                    <input   placeholder="lastname"
                             id="lastname"
                             required
                             name="lastname"
                             spellcheck="false"
                             class="form-control"
                             value="{{ old('lastname') }}"
                    />
                    @if ($errors->get('lastname'))
                        <div class="alert alert-dismissable alert-danger">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <strong>{{ $errors->first('lastname') }}</strong>

                        </div>
                    @endif
                </div>

                <div class="form-group">
                     <span>
                    <label for="ID-card">Street</label>
                    <input   placeholder="street"
                             id="street"
                             required
                             name="street"
                             spellcheck="false"
                             class="form-control"
                             value="{{ old('street') }}"
                    />
                         @if ($errors->get('street'))
                             <div class="alert alert-dismissable alert-danger">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <strong>{{ $errors->first('street') }}</strong>

                        </div>
                         @endif

                         <label for="ID-card">House no.<span class="required">*</span></label>
                    <input   placeholder="house no"
                             id="house no"
                             required
                             name="house_no"
                             spellcheck="false"
                             class="form-control"
                             value="{{ old('house_no') }}"
                    />
                    </span>
                </div>
                <div class="form-group" style="padding-top: 15px">
                    <label for="address">Postal code</label>
                    <input placeholder="postal code"
                           style="resize: vertical"
                           id="postal_code"
                           name="postal_code"
                           spellcheck="false"
                           class="form-control"
                           value="{{ old('postal_code') }}"

                    />

                </div>


                <div class="form-group">
                    <label for="email">Email<span class="required">*</span></label>
                    <input placeholder="Email"
                           style="resize: vertical"
                           required
                           id="email"
                           name="email"
                           spellcheck="false"
                           class="form-control "
                           value="{{ old('email') }}"
                    />
                    @if ($errors->get('email'))
                        <div class="alert alert-dismissable alert-danger">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <strong>{{ $errors->first('email') }}</strong>

                        </div>
                    @endif

                </div>


                <div class="form-group">
                    <label for="phone">Phone<span class="required">*</span></label>
                    <input placeholder="Phone"
                           style="resize: vertical"
                           required
                           id="phone"
                           name="phone"
                           spellcheck="false"
                           value="{{ old('phone') }}"
                           class="form-control "/>
                    @if ($errors->get('phone'))
                        <div class="alert alert-dismissable alert-danger">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <strong>{{ $errors->first('phone') }}</strong>

                        </div>
                    @endif
                </div>

                <div class="form-group">
                    <label for="position">Bank Account<span class="required">*</span></label>
                    <input placeholder="Bank Account Number"
                           style="resize: vertical"
                           required
                           id="bank_account"
                           name="bank_account"
                           spellcheck="false"
                           value="{{ old('bank_account') }}"
                           class="form-control "/>

                </div>

                <div class="form-group">
                    <input type="submit" class="btn btn-primary"
                           value="Save"/>
                </div>
            </form>
        </div>


    </div>


    <div class="col-sm-3 col-md-3 col-lg-3 pull-right" style="padding-top:20px">
        <div class="sidebar-module">
            <h4>Actions</h4>
            <ol class="list-unstyled">

                <li><a href="/employees"><i class="fa fa-users" aria-hidden="true"></i> All employees</a></li>
                <!--<li><a href="/departments"><i class="fa fa-building-o" aria-hidden="true"></i>
                        All departments</a></li>-->
            </ol>
        </div>
    </div>
@endsection