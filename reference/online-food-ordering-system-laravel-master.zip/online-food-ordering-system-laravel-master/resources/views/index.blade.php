@extends('layouts.clientLayout')

@section('content')
<style>
    .fa-minus:hover{
        cursor: pointer;
        color:grey;
    }
    .fa-plus:hover{
        cursor: pointer;
        color:grey;
    }

    @media screen and (max-height: 991px) {
        #cart {
        }
    }
    @media screen and (min-height: 992px) {
        #cart {
            position:fixed;
        }
    }
    @media (max-width: 992px){
        .sticky {
            margin-top: 0px;
            padding-left: 0px;
            padding-right: 0px;
            top: 92px !important;
            z-index: 999;
            position: fixed !important;
            width: 100% !important;
            right: 0px;
            left:0px;
            height: 100%;
            background: none;
        }

        #cart{
            display:none;
        }
        #shop{
            display:block;
            margin-top: 0px;
            width: 100%;
            top: 55px !important;
            z-index: 999;
            position: fixed !important;
            left: 0px;
            right: 0px;
            background-color: white;
        }
    }

    @media (min-width: 993px){
        #shop{
            display: none;
        }
    }
</style>

    <div class="col-md-12">
        <button  class="btn" id="shop" type="button"  ><i class="fa fa-shopping-cart"></i> <i class="fa fa-angle-double-down"></i></button>
    </div>


    @foreach($products as $product)
        <div class="col-md-4 ">
            <div class="card h-100">
                <a href="#">
                    @if(file_exists( public_path().'/product_images/'.$product->id.'.jpg' ))
                        <img class="img-responsive img-thumbnail" src="{{asset('product_images/'.$product->id.'.jpg')}}"
                             style="height:150px; width:100%;">
                    @else
                        <i class="fas fa-utensils fa-3x img-thumbnail" style="width:150%; height:100px;"></i>
                    @endif
                </a>
                <div class="card-body">
                    <h5 class="card-title">
                        {{$product->title}}
                    </h5>
                    <p class="card-text" style="font-size: 12px">{{$product->description}}</p>
                </div>
                <div class="card-footer">
                    <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                    <button class="btn btn-default pull-right btnOrder"
                            style="background-color: white; border-color: gray; border-style: solid;"
                            id="btnOrder{{$product->id}}"><i class="fa fa-shopping-cart"></i>
                        {{$product->food_products_prices->min('price')}} &euro;
                    </button>
                </div>
            </div>
        </div>
    @endforeach

    <div class="modal" tabindex="-1" role="dialog" id="spinnerModal" style="">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content"  style="background-color: transparent; border: none; text-align: center;">
                <div class="modal-body">
                   <img src="{{asset('spinner.gif')}}" height="150px" width="150px">
                </div>
            </div>
        </div>
    </div>

    <!-- Start modal for choosing quantity and ingredients -->
    <div class="modal fade" tabindex="-1" role="dialog" id="modalOrder">
        <div class="modal-dialog" role="document" style="max-width:800px; max-height: 900px; min-height:900px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add to cart</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4" id="productDescription">
                            </div>
                            <div class="col-md-8">
                                <table class="table">
                                    <tr>
                                        <td colspan="3">Optional</td>
                                    </tr>
                                    <tbody id="optionalIngedients">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" id="modalBasicPrice1" value="0">
                    <input type="hidden" id="modalIngredientsBasicPrice">
                    <h4>Subtotal: <span id="modalSubtotal"> </span> &euro;</h4>
                    <button type="button" id="modalAddToCart" class="btn btn-primary">Add</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- End of modal for choosing quantity and ingredients -->

    <script>
        $(document).ready(function () {
            $(".btnOrder").click(function () {
                $("#spinnerModal").modal('show');
                $('#spinnerModal').modal({
                    backdrop: 'static',
                    keyboard: false
                });
                //make sure that everything is empty before appending new elements
                $("#optionalIngedients").empty();
                $("#productDescription").empty();
                $('#modalIngredientsBasicPrice').val(0);
                $('#modalBasicPrice1').val(0);

                //main functionality
                id = $(this).attr('id').substr(8);
                $.ajax({
                    type: 'POST',
                    url: "/getProduct",
                    data: {
                        '_token': '{{csrf_token()}}',
                        'id': id
                    },
                    success: function (response) {
                        $("#productDescription").append(
                            " <div class='card h-100'> " +
                               "<a href='#'> " +
                                 "<img class='img-responsive img-thumbnail' id='productImage' src='/product_images/" + response['product'].id + ".jpg' style='height:150px; width:100%;'> " +
                               "</a> " +
                               "<div class='card-body'> " +
                                    "<h5 class='card-title'> " +
                                           response['product'].title +
                                    "</h5> " +
                                     "<span id='spanprice'></span> " +
                                     "<p class='card-text' style='font-size: 12px' id='modalProductDescription'>" + response['product'].description + "</p><span id='optionals'></span> " +
                                 "</div> " +
                                "<div class='card-footer'> " +
                                    "<div class='input-group'> " +
                            "<button type='button' class='btn btn-default' id='modalQuantitySub'>-</button>"+
                            "<input size='4' type='text' style='text-align: center;' class='form-control' disabled id='modalQuantityValue' value='1'> " +
                                    "<div class='input-group-btn'> " +
                                      "<button type='button' class='btn btn-default' id='modalQuantityAdd'>+</button> " +
                                    "</div> " +
                                "</div> " +
                                "</div> " +
                            "</div>"
                        );

                        if(response['prices'].length>1)
                        {
                            var select="<select name='selectSize' id='selectSize' class='form-control'>";
                            var options="";
                            $.each(response['prices'], function (key, value) {
                                options+="<option value='"+response['prices'][key].price+"'>"+response['prices'][key].size+"</option>";
                            });
                            $('#spanprice').append("Select Size:<br> "+select+options+"</select>");

                        }
                        else
                        {
                            $('#spanprice').append("<h5>"+response['prices'][0].price+" &euro;<h5>");
                        }
                        $('#modalSubtotal').text(response['prices'][0].price);
                        $('#modalSubtotal').val(response['prices'][0].price);
                        $('#modalBasicPrice').val(response['prices'][0].price);
                        $('#modalBasicPrice1').val(response['prices'][0].price);


                        $.each(response['ingredients'], function (key, value) {
                            $('#optionalIngedients').append(
                                "<tr>" +
                                "<td id='ingredientTitle"+response['ingredients'][key].id+"' style='border: none'>" + response['ingredients'][key].title + "</td>" +
                                "<td style='border: none'>" + response['ingredients'][key].price + " &euro;</td>" +
                                "<td style='border: none'>" +
                                " <button type='button' onclick='addIngredient("+response['ingredients'][key].id+","+response['ingredients'][key].price+")' class='btn btn-warning modalIngredientAdd' data-id='"+response['ingredients'][key].id+"' id='ingredientAdd"+response['ingredients'][key].id+"' value='"+response['ingredients'][key].price+"'>+</button>" +
                                " <button type='button' onclick='removeIngredient("+response['ingredients'][key].id+","+response['ingredients'][key].price+")' style='display: none;' class='btn btn-danger modalIngredientDelete' data-id='"+response['ingredients'][key].id+"' id='ingredientDelete"+response['ingredients'][key].id+"' value='"+response['ingredients'][key].price+"'>-</button></td>"+
                                "</tr>"
                            );
                        });

                        $('#optionalIngedients').append('<tr><td colspan="3"><small>Extra info</small><textarea rows="3" id="modalExtra" class="form-control"></textarea></td></tr>');

                        $("#spinnerModal").modal('hide');
                        $("#modalOrder").modal("show");
                    }
                });
            });

            //Button to increase quantity
            $(document).on("click","#modalQuantityAdd",function(){
                basicPrice=$('#modalBasicPrice1').val();
                $("#modalQuantityValue").val(parseInt($("#modalQuantityValue").val())+1);
                ingred=parseFloat($('#modalIngredientsBasicPrice').val());
                priceNow=parseFloat(basicPrice)+ingred;
                var subtotal=parseFloat(priceNow)*parseFloat($("#modalQuantityValue").val());
                $("#modalSubtotal").text(subtotal.toFixed(2));
            });

            //Button to decrease quantity
            $(document).on("click","#modalQuantitySub",function(){
                if(parseInt($("#modalQuantityValue").val())==1)
                {
                    return;
                }
                basicPrice=$('#modalBasicPrice1').val();

                $("#modalQuantityValue").val(parseInt($("#modalQuantityValue").val())-1);
                ingred=parseFloat($('#modalIngredientsBasicPrice').val());
                priceNow=parseFloat(basicPrice)+ingred;
                var subtotal=parseFloat(priceNow)*parseFloat($("#modalQuantityValue").val());
                $("#modalSubtotal").text(subtotal.toFixed(2));
            });

            //when size changes
            $(document).on("change","#selectSize",function(){
                priceSize=parseFloat($(this).val());
                $('#modalBasicPrice1').val(priceSize);
                quantity=parseInt($("#modalQuantityValue").val());
                ingred=parseFloat($('#modalIngredientsBasicPrice').val());
                subtotal=quantity*(priceSize+ingred);
                $("#modalSubtotal").text(subtotal.toFixed(2));
            });

            //make sure to clear everything in modal every time the modal is hidden
            $("#modalOrder").on("hidden.bs.modal", function () {
                $("#optionalIngedients").empty();
                $("#productDescription").empty();
                $("#modalSubtotal").empty();
                $('#modalIngredientsBasicPrice').val(0);
                $('#modalBasicPrice1').val(0);
                $('#modalQuantityValue').val(1);
            });
        });

    </script>
    <script>
        ingredientsPrice= $('#modalIngredientsBasicPrice');
        basicPrice1= $('#modalBasicPrice1');
        subTotal1= $("#modalSubtotal");

        //funksionet
        //function to remove ingredient
        function removeIngredient(id,price)
        {
            $(document).ready(function () {
                ingredientsPrice.val(parseFloat( ingredientsPrice.val())-parseFloat(price));

                var subtotal1=parseInt($('#modalQuantityValue').val())*(parseFloat(basicPrice1.val())+parseFloat(ingredientsPrice.val()));
                subTotal1.text(subtotal1.toFixed(2));
                $('#spanIngredient'+id).remove();
                $("#ingredientDelete"+id).css('display','none');
                $("#ingredientAdd"+id).css('display','block');
            });
        }
        //function to add ingredient
        function addIngredient(id,price)
        {
            $(document).ready(function(){
                ingredientsPrice.val(parseFloat(price)+parseFloat(ingredientsPrice.val()));
                var subtotal1=parseInt($('#modalQuantityValue').val())*(parseFloat(basicPrice1.val())+parseFloat(ingredientsPrice.val()));
                subTotal1.text(subtotal1.toFixed(2));
                $("#ingredientAdd"+id).css('display','none');
                $("#ingredientDelete"+id).css('display','block');
                $('#optionals').append("<span id='spanIngredient"+id+"'><span class='badge badge-pill badge-warning'>+</span> " +
                    "<small><span class='optionalIngredientsClass'>"+$('#ingredientTitle'+id).text()+"</span><i class='fas fa-minus pull-right' id='minus' onclick='removeIngredient("+id+","+price+")'></i></small><br></span>");
            });
        }

        //function to Increase Quantity of product in Cart
        function cartQuantityAdd(rowId)
        {
            $(document).ready(function(){
                $.ajax({
                    type: 'POST',
                    url: "/cartQuantityAdd",
                    data: {
                        '_token': '{{csrf_token()}}',
                        'rowId':rowId
                    },
                    success: function (response) {
                        $("#"+rowId+" .quantity").text(response['item']['qty']);
                        $("#"+rowId+" .cartSubtotal").text(response['subtotal'].toFixed(2));
                        $("#cartTotal").text(response['total']);
                    },
                    error: function (textStatus, errorThrown) {
                        alert("error");
                    }
                });
            });
        }
        //function to Decrease Quantity of product in Cart
        function cartQuantityRemove(rowId)
        {
            $(document).ready(function(){
                $.ajax({
                    type: 'POST',
                    url: "/cartQuantityRemove",
                    data: {
                        '_token': '{{csrf_token()}}',
                        'rowId':rowId
                    },
                    success: function (response) {
                        if(response['status']=="LastItem")
                        {
                            $("#"+rowId).remove();
                        }
                        else
                        {
                            $("#"+rowId+" .quantity").text(response['item']['qty']);
                            $("#"+rowId+" .cartSubtotal").text(parseFloat(response['subtotal']).toFixed(2));
                        }
                        if(response['total']==0)
                        {
                            $('#produktetEshtuara').append("<li class='list-group-item'>There are no products!</li>");
                        }
                        $("#cartTotal").text(response['total']);

                    },
                    error: function (textStatus, errorThrown) {
                        alert("error");
                    }
                });
            });
        }

        //post method to add product with options in Cart
        $(document).ready(function(){
            $('#modalAddToCart').click(function(){
                var options=[];
                options["size"]="";
                options['ingredients']=[];
                options['extras']="";
                options['extras']=$('#modalExtra').val();

                var index=0;
                if($('span.optionalIngredientsClass').length)
                {
                    $('.optionalIngredientsClass').each(function(){
                    options['ingredients'][index]=$(this).text();
                    index++;
                    });
                }
                if($('#selectSize').length)
                {
                    options["size"]=$('#selectSize').find(":selected").text();
                }

                $.ajax({
                    type: 'POST',
                    url: "/addToCart",
                    data: {
                        '_token': '{{csrf_token()}}',
                        'id':id,
                        'price': parseFloat($('#modalIngredientsBasicPrice').val())+parseFloat($('#modalBasicPrice1').val()),
                        'quantity':parseInt($('#modalQuantityValue').val()),
                        'options':Object.assign({},options)
                    },
                    success: function (response) {
                        $('#produktetEshtuara').empty();
                        $("#modalOrder").modal("hide");
                        $('#cartTotal').text(response['total']);

                        $.each(response['cart'], function (key, value){
                            size="";
                            ingredients="";
                            extras="";

                            if(response['cart'][key].options.extras!=null)
                            {
                                extras="<small><b class='text-warning'>Extras: </b> "+response['cart'][key].options.extras+"</small><br>";
                            }
                            if(response['cart'][key].options.size!=null)
                            {
                                size="<small class='pull-right'><b>Size:</b> "+response['cart'][key].options.size+"</small>";
                            }
                            if(response['cart'][key].options.ingredients!=null)
                            {
                                $.each(response['cart'][key].options.ingredients, function (key1, value1){
                                    ingredients+="<span><span class='badge badge-pill badge-warning'>+</span> " +
                                        "<small>"+value1+"</small><br></span>";
                                });
                            }
                            $('#produktetEshtuara').append("<li class='list-group-item' id='"+response['cart'][key].rowId+"'> " +
                                "<small><b><span class='quantity'>"+response['cart'][key].qty+"</span>x "+response['cart'][key].name+"</b></small> " +
                                "<span class='pull-right' style='color:lightgray'> " +
                                "<i class='fas fa-minus' onclick='cartQuantityRemove(\""+response['cart'][key].rowId+"\")'></i> " +
                                "<i class='fas fa-plus' onclick='cartQuantityAdd(\""+response['cart'][key].rowId+"\")'></i></span> " +
                                "<br> " +
                                  ingredients+ extras+ size+
                                "<hr> " +
                                "<span class='pull-right'><small class='cartSubtotal'>"+parseFloat(response['cart'][key].subtotal).toFixed(2)+" </small><small> &euro;</small></span> </li>");
                        });

                    },
                    error: function (textStatus, errorThrown) {
                        alert("error");
                    }
                });
            });
        })
        $(document).ready(function(){
            $.ajax({
                type: 'POST',
                url: "/cartItems",
                data: {
                    '_token': '{{csrf_token()}}'
                },
                success: function (response) {
                    if(response['cart'].length==0)
                    {
                        $('#produktetEshtuara').append("<li class='list-group-item'>There are no products!</li>");
                    return;}
                    $('#cartTotal').text(response['total']);
                    $.each(response['cart'], function (key, value){
                        size="";
                        ingredients="";
                        extras="";

                        if(response['cart'][key].options.extras!=null)
                        {
                            extras="<small><b class='text-warning'>Extra: </b> "+response['cart'][key].options.extras+"</small><br>";
                        }
                        if(response['cart'][key].options.size!=null)
                        {
                            size="<small class='pull-right'><b>Size:</b> "+response['cart'][key].options.size+"</small>";
                        }
                        if(response['cart'][key].options.ingredients!=null)
                        {
                            $.each(response['cart'][key].options.ingredients, function (key1, value1){
                                ingredients+="<span><span class='badge badge-pill badge-warning'>+</span> " +
                                    "<small>"+value1+"</small><br></span>";
                            });
                        }

                        $('#produktetEshtuara').append("<li class='list-group-item' id='"+response['cart'][key].rowId+"'> " +
                            "<small><b><span class='quantity'>"+response['cart'][key].qty+"</span>x "+response['cart'][key].name+"</b></small> " +
                            "<span class='pull-right' style='color:lightgray'> " +
                            "<i class='fas fa-minus' onclick='cartQuantityRemove(\""+response['cart'][key].rowId+"\")'></i> " +
                            "<i class='fas fa-plus' onclick='cartQuantityAdd(\""+response['cart'][key].rowId+"\")'></i></span> " +
                            "<br> " +
                             ingredients+ extras+ size+
                            "<hr> " +
                            "<span class='pull-right'><small class='cartSubtotal'>"+parseFloat(response['cart'][key].subtotal).toFixed(2)+" </small><small> &euro;</small></span> </li>");
                    });
                },
                error: function (textStatus, errorThrown) {
                    alert("error");
                }
            });
        });

    </script>
@endsection

@section('cart')
    <div id="cart" class="sticky" style=" width: 100%; min-height:300px;overflow-y: auto;">
        <div class="card border-default mb-3" style=" min-height:300px; overflow-y: auto;">
            <div class="card-header bg-transparent border-default"><i class="fas fa-shopping-cart" ></i> Shopping Cart
            </div>
            <div id="content">
            <div class="card-body">
                <ul class="list-group" id="produktetEshtuara" style="overflow-y: auto; max-height: 300px;">
                </ul>
            </div>
            <div class="card-footer bg-transparent border-warning">Total:<h4 class="pull-right"> <span id="cartTotal"> 0.00</span> &euro;</h4><br>
                <button class="btn btn-success form-control">Order Now</button>
            </div>
            </div>
        </div>
    </div>
  <script>
      $(document).ready(function(){
          $('#shop').click(function(){
              $('#cart').toggle();
          });
      });
  </script>
@endsection