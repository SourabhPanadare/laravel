@extends('layouts.template')

@section('content')
    <div class="row col-md-9 col-lg-9 col-sm-9  " style="background: white; margin-bottom: 30px;">
        <h2>Add new Product</h2>
        <!-- Example row of columns -->
        <div class="row  col-md-12 col-lg-12 col-sm-12">

            <form method="post" action="{{ route('food_products.store') }}" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="form-group">
                    <label for="title">Title<span class="required">*</span></label>
                    <input placeholder="title"
                           id="title"
                           required
                           name="title"
                           spellcheck="false"
                           class="form-control"
                           value="{{ old('title') }}"
                    />
                    @if ($errors->get('title'))
                        <div class="alert alert-dismissable alert-danger">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <strong>{{ $errors->first('title') }}</strong>

                        </div>
                    @endif
                </div>

                <div class="form-group">
                    <label for="description">Description<span class="required">*</span></label>
                    <input placeholder="description"
                           id="description"
                           required
                           name="description"
                           spellcheck="false"
                           class="form-control"
                           value="{{ old('description') }}"
                    />
                    @if ($errors->get('description'))
                        <div class="alert alert-dismissable alert-danger">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <strong>{{ $errors->first('description') }}</strong>
                        </div>
                    @endif
                </div>
                <div class="form-group">
                    <label for="email">Select category<span class="required">*</span></label>
                    <select class="form-control" name="category_ID" required>
                        @foreach($categories as $category)
                            <option value="{{$category->id}}">
                                {{$category->title}}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="form-group">
                    <label for="image">Choose image</label>
                    <input class="form-control" type="file" name="image">
                </div>
                <div class="form-group text-center">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="options" id="nooptions" value="option1">
                        <label class="form-check-label" for="inlineRadio2">Fixed Price</label>

                        <input class="form-check-input" type="radio" name="options" id="withoptions" value="option2">
                        <label class="form-check-label" for="inlineRadio3">Different Prices</label>
                    </div>
                </div>
                <div id="addOptions" class="text-center" style="display: none;">
                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModal">Add option <i
                                class="fa fa-plus"></i></button>
                </div>
                <div style="display: none;" id="hiddenGroup">
                    <div class="input-group-addon">
                        <input type="text" name="price" class="form-control text-center" aria-label="Amount (to the nearest dollar)">
                        <div class="input-group-append">
                            <span  class="input-group-text">Price &euro;</span>
                        </div>
                    </div>
                </div>
                <br>
                <table id="optionsDiv" class="table table-bordered">

                </table>


                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label>Select size</label>
                                    <select class="form-control" id="size">
                                        @foreach($sizes as $size)
                                            <option value="{{$size->id}}">{{$size->size}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="input-group-addon">
                                    <input type="text" class="form-control text-center"
                                           aria-label="Amount (to the nearest dollar)" id="priceOption">
                                    <div class="input-group-append">
                                        <span class="input-group-text">Price &euro;</span>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary" id="add">Add+</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal End-->
                <br>
                <label>Choose optional ingredients:</label>
                @foreach($ingredients as $ingredient)
                    <div class="form-group">
                        <input type="checkbox" name="ingredients[]" value="{{$ingredient->id}}">
                        <label>{{$ingredient->title}}</label>

                    </div>
                @endforeach
                <div class="form-group">
                    <input type="submit" class="btn btn-primary pull-right"
                           value="Save"/>
                </div>
            </form>
        </div>


    </div>


    <div class="col-sm-3 col-md-3 col-lg-3 pull-right" style="padding-top:20px">
        <div class="sidebar-module">
            <h4>Actions</h4>
            <ol class="list-unstyled">

                <li><a href="/food_products"><i class="fa fa-play" aria-hidden="true"></i> All products</a></li>
                <!--<li><a href="/departments"><i class="fa fa-building-o" aria-hidden="true"></i>
                        All departments</a></li>-->
            </ol>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $("#nooptions").click(function () {
                $("#hiddenGroup").css("display", "block");
                $("#addOptions").css("display", 'none');
                $("#optionsDiv").empty();
            });
        });
        $(document).ready(function () {
            $("#withoptions").click(function () {
                $("#hiddenGroup").css("display", "none");
                $("#addOptions").css("display", 'block');
            });
        });
        $(document).ready(function () {
            $("#add").click(function () {
                sizeName=$('#size :selected').text();
                size = $('#size').val();
                price = $('#priceOption').val();
                $('#optionsDiv').append(
                    '<tr><td><label>' + sizeName+ '</label></td><td>Price: ' + price +
                    '&euro;</td><input type="hidden"  name="size[]" value="' + size + '">' +
                    '<input type="hidden"  name="price'+size+'" value="' + price + '"></tr>'
                );

            });
        });

    </script>
@endsection