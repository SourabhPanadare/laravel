@extends('layouts.template')

@section('content')

    <!-- "-->

        <div class="row col-md-10" style="background-color: white; margin-left:4px">
            <h2>All Products</h2>
            <div style="overflow-x: auto">
            <table class="table" style="border:2px solid gainsboro;">
                <thead>
                <tr style="background-color: #E4EDDB;">
                    <th>Name</th>
                    <th>Description</th>
                    <th>Category</th>
                   <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                @foreach($products as $product)
                    <tr>
                        <td><strong>{{$product->title}}</strong></td>
                        <td>{{$product->description}} </td>
                        <td>{{$product->category->title}}</td>
                        <td>
                            @if(file_exists( public_path().'/product_images/'.$product->id.'.jpg' ))
                            <img class="img-responsive img-thumbnail" src="{{asset('product_images/'.$product->id.'.jpg')}}" style="height: 100px; width: 100px;">
                                @else
                                <i class="fas fa-utensils fa-3x img-thumbnail" style="width:100px; height: 100px;"></i>
                            @endif
                        </td>
                        <td><a href="/food_products/{{$product->id}}/edit"><button class="btn btn-info " value="Edit">Edit <i class="fa fa-edit"></i></button></a></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
                {{ $products->links() }}
            </div>
        </div>
        <div class="col-sm-2 col-md-2 col-lg-2 pull-right" >
            <div class="sidebar-module">
                <h4>Actions</h4>
                <ol class="list-unstyled">
                    <li><a href="/food_products/create"><i class="fa fa-user" aria-hidden="true"></i> Add new product</a></li>
                </ol>
            </div>
        </div>



@endsection