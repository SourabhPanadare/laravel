@extends('layouts.template')

@section('content')
    <div class="row col-md-9 col-lg-9 col-sm-9  " style="background: white;">
        <h2>Create new Ingredient</h2>

        <!-- Example row of columns -->
        <div class="row  col-md-12 col-lg-12 col-sm-12" >
            <form method="post" action="{{ route('food_ingredients.store') }}">
                {{ csrf_field() }}
                <div class="form-group">
                    <label for="name">Name<span class="required">*</span></label>
                    <input   placeholder="name"
                             id="title"
                             required
                             name="title"
                             spellcheck="false"
                             class="form-control"
                             value="{{ old('title') }}"
                    />
                    @if ($errors->get('title'))
                        <div class="alert alert-dismissable alert-danger">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <strong>{{ $errors->first('title') }}</strong>
                        </div>
                    @endif
                </div>

                <div class="form-group">
                    <label>Price</label>
                    <div class="input-group-addon" >
                        <input type="text" class="form-control text-center" aria-label="Amount (to the nearest dollar)" name="price">
                        <div class="input-group-append">
                            <span class="input-group-text">Price &euro;</span>
                        </div>
                    </div>
                </div>



        <div class="form-group">
            <input type="submit" class="btn btn-primary"
                   value="Save"/>
        </div>
        </form>
        </div>


    </div>


    <div class="col-sm-3 col-md-3 col-lg-3 pull-right" style="padding-top:20px">
        <div class="sidebar-module">
            <h4>Actions</h4>
            <ol class="list-unstyled">

                <li><a href="/food_ingredients"><i class="fa fa-users" aria-hidden="true"></i> All Ingredients</a></li>
                <!--<li><a href="/departments"><i class="fa fa-building-o" aria-hidden="true"></i>
                        All departments</a></li>-->
            </ol>
        </div>
    </div>
@endsection