@extends('layouts.template')

@section('content')

    <!-- "-->

        <div class="row col-md-10" style="background-color: white; margin-left:4px">
            <h2>Ingredients</h2>
            <div style="overflow-x: auto">
            <table class="table" style="border:2px solid gainsboro;">
                <thead>
                <tr  style="background-color: #E4EDDB;">
                    <th width="50%">Name</th>
                    <th width="40%">Price</th>
                    <th width="10%"></th>
                </tr>
                </thead>
                <tbody>
                @foreach($ingredients as $ingredient)
                    <tr>
                        <td width="70%">{{$ingredient->title}}</td>
                        <td width="20%">{{$ingredient->price}} &euro;</td>
                        <td width="10%"><a href="/food_ingredients/{{$ingredient->id}}/edit"><button class="btn btn-info " value="Edit">Edit <i class="fa fa-edit"></i></button>
                                </a></td>

                    </tr>
                @endforeach
                </tbody>
            </table>
            </div>
        </div>
        <div class="col-sm-2 col-md-2 col-lg-2 pull-right" >
            <div class="sidebar-module">
                <h4>Actions</h4>
                <ol class="list-unstyled">
                    <li><a href="/food_ingredients/create"><i class="fa fa-plus" aria-hidden="true"></i> Add new ingredient</a></li>
                </ol>
            </div>
        </div>



@endsection