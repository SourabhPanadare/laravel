@extends('layouts.template')

@section('content')

    <!-- "-->

        <div class="row col-md-10" style="background-color: white; margin-left:4px">
            <h2>Categories</h2>
            <div style="overflow-x: auto">
            <table class="table" style="border:2px solid gainsboro;">
                <thead>
                <tr  style="background-color: #E4EDDB">
                    <th width="10%">ID</th>
                    <th width="70%">Category</th>
                    <th width="10%"></th>
                    <th width="10%"></th>
                </tr>
                </thead>
                <tbody>
                @foreach($categories as $category)
                    <tr>
                        <td width="10%">{{$category->id}}</td>
                        <td width="60%">{{$category->title}}</td>
                        <td width="10%"><i class="fas fa-eye "></i></td>
                        <td width="10%"><a href="/food_categories/{{$category->id}}/edit"><button class="btn btn-info " value="Edit">Edit <i class="fa fa-edit"></i></button>
                                </a></td>

                    </tr>
                @endforeach
                </tbody>
            </table>
            </div>
        </div>
        <div class="col-sm-2 col-md-2 col-lg-2 pull-right" >
            <div class="sidebar-module">
                <h4>Actions</h4>
                <ol class="list-unstyled">
                    <li><a href="/food_categories/create"><i class="fa fa-plus" aria-hidden="true"></i> Create new category</a></li>
                </ol>
            </div>
        </div>



@endsection