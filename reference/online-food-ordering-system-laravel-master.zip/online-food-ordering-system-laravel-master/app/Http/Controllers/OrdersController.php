<?php

namespace App\Http\Controllers;

use App\Food_Product;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Cart;

class OrdersController extends Controller
{
    public function addToCart(Request $request)
    {
        //return Cart::content();
        $id=$request->id;
        $price=$request->price;
        $quantity=$request->quantity;
        $options=$request->options;
        $product=Food_Product::find($id);

       Cart::add($id,"$product->title",$quantity,$price,$options);

       $response=[];
       $response['total']=Cart::total();

       $response['cart']=Cart::content();

        return $response;

    }

    public function cartQuantityAdd(Request $request)
    {
        $rowId=$request->rowId;
        $response=[];
        Cart::update($rowId, ['qty' => Cart::get($rowId)->qty+1]);
        $response['item']=Cart::get($rowId);

        $response['subtotal']=Cart::get($rowId)->subtotal;
        $response['total']=Cart::total();
        return $response;
    }

    public function cartQuantityRemove(Request $request)
    {
        $rowId=$request->rowId;
        $item=Cart::get($rowId);

        $response=[];
        if($item->qty==1)
        {
            Cart::remove($rowId);
            $response['status']="LastItem";
        }
        else
        {
            Cart::update($rowId, ['qty' => Cart::get($rowId)->qty-1]);
            $response['status']="NotLastItem";
            $response['item']=Cart::get($rowId);
            $response['subtotal']=Cart::get($rowId)->subtotal;
        }
        $response['total']=Cart::total();
        return $response;

    }

    public function cartItems(Request $request)
    {
        $response=[];
        $response['cart']=Cart::content();
        $response['total']=Cart::total();
        return $response;
    }
}
