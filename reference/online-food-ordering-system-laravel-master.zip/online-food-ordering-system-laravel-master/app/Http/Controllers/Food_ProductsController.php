<?php

namespace App\Http\Controllers;

use App\Food_Category;
use App\Food_Ingredient;
use App\Food_Product;
use App\Food_Products_Ingredient;
use App\Food_Products_Price;
use App\Food_Size;
use Illuminate\Http\Request;
use Image;

class Food_ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        //
        $products=Food_Product::paginate(5);
        return view('food_products.index',['products'=>$products]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories=Food_Category::all();
        $ingredients=Food_Ingredient::all();
        $sizes=Food_Size::all();
        return view('food_products.create',['categories'=>$categories,'ingredients'=>$ingredients,'sizes'=>$sizes]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        if($request->input('price')=="" && !$request->has('size') ) {
            $request->session()->flash('error', 'Please set any price!');
            return redirect()->route('food_products.create');
        }
        $product=Food_Product::create(
            [
                'title'=>$request->input('title'),
                'description'=>$request->input('description'),
                'category_ID'=>$request->input('category_ID')

            ]
        );

        if($product)
        {
            if($request->has('ingredients')) {
                foreach ($request->input('ingredients') as $ingredient_id) {
                    $food_products_ingredient = Food_Products_Ingredient::create(
                        [
                            'product_ID' => $product->id,
                            'food_ingredient_ID' => $ingredient_id
                        ]
                    );
                }
            }
            if($request->has('size'))
            {
                foreach ($request->input('size') as $size)
                {
                    $food_products_prices = Food_Products_Price::create(
                        [
                            'product_ID' => $product->id,
                            'size_ID'=>$size,
                            'price' =>  $request->input('price'.$size)
                        ]
                    );
                }
            }
            else
            {
                $food_products_prices = Food_Products_Price::create(
                    [
                        'product_ID' => $product->id,
                        'size_ID'=>null,
                        'price' =>  $request->input('price')
                    ]
                );

            }
            if($request->hasFile('image')){
                $avatar = $request->file('image');
                $filename = $product->id. '.jpg';
                Image::make($avatar)->resize(300, 300)->save( public_path('/product_images/' . $filename ) );
            }
            return redirect()->route('food_products.index')->with('success','New product created successfully!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function getProduct(Request $request)
    {
        $id=$request->id;
        $product=Food_Product::findOrFail($id);
        $productingredients=Food_Products_Ingredient::where('product_ID',$id)->get();

        $food_prices=Food_Products_Price::where('product_ID',$id)->get()->sortBy('price');

        $ingredients=[];
        $prices=[];
        $i=0;
        foreach ($productingredients as $ingredient)
        {
            $ingredients[$i]['id']=$ingredient->food_ingredient->id;
            $ingredients[$i]['title']=$ingredient->food_ingredient->title;
            $ingredients[$i]['price']=$ingredient->food_ingredient->price;

            $i++;
        }
        $i=0;
        foreach ($food_prices as $price)
        {
           $prices[$i]['id']=$price->id;
           if($price->size_ID==null)
           {
               $prices[$i]['size']='none';
           }
           else
           {
            $prices[$i]['size']=$price->food_size->size;
           }
            $prices[$i]['price']=$price->price;
           $i++;
        }

        $response=[];
        $response["product"]=$product;
        $response["ingredients"]=$ingredients;
        $response["prices"]=$prices;
        return $response;
    }
}
