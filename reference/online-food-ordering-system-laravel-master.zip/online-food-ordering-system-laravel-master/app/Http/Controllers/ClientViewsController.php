<?php

namespace App\Http\Controllers;

use App\Food_Category;
use Illuminate\Http\Request;

class ClientViewsController extends Controller
{
    //
    public function index()
    {
    }
}
