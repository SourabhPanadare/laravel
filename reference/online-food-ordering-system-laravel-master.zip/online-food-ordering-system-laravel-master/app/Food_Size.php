<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Food_Size extends Model
{
    protected $table='food_sizes';
    public $timestamps=false;

    protected $fillable=[
        'id',
       'size'
    ];

}
