<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Food_Ingredient extends Model
{
      protected $table='food_ingredients';
    public $timestamps=false;

    protected $fillable=[
        'id',
        'title',
        'price'
    ];

    public function food_products_ingredients()
    {
        return $this->hasMany('App\Food_Products_Ingredient');
    }
}
