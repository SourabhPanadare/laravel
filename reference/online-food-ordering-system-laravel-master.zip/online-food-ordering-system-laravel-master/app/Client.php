<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    protected $table='clients';
    public $timestamps=false;

    protected $fillable=[
        'id',
        'firstname',
        'lastname',
        'address',
        'email',
        'postal_code',
        'ip_address'
    ];

}
