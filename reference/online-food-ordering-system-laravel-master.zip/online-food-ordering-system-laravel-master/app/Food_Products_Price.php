<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Food_Products_Price extends Model
{
    protected $table='food_products_prices';
    public $timestamps=false;

    protected $fillable=[
        'id',
        'product_ID',
        'size_ID',
        'price'
    ];

    public function food_product()
    {
        return $this->belongsTo('App\Food_Product','product_ID');
    }
    public function food_size()
    {
        return $this->belongsTo('App\Food_Size','size_ID');
    }
}
