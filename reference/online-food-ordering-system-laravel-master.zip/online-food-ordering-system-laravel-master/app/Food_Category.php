<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Food_Category extends Model
{
    protected $table='food_categories';
    public $timestamps=false;

    protected $fillable=[
        'id',
        'title'
    ];

    public function products()
    {
        return $this->hasMany('App\Food_Product');
    }
}
