<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $table='employees';
    public $timestamps=false;

    protected $fillable=[
        'id',
        'firstname',
        'lastname',
        'address',
        'email',
        'phone',
        'postal_code',
        'bank_account'
    ];

}
