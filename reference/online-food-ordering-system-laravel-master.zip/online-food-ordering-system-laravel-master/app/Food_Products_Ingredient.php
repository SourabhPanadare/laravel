<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Food_Products_Ingredient extends Model
{
    protected $table='food_products_ingredients';
    public $timestamps=false;

    protected $fillable=[
        'id',
        'product_ID',
        'food_ingredient_ID'
    ];

    public function food_product()
    {
        return $this->belongsTo('App\Food_Product','product_ID');
    }
    public function food_ingredient()
    {
        return $this->belongsTo('App\Food_Ingredient','food_ingredient_ID');
    }
}
