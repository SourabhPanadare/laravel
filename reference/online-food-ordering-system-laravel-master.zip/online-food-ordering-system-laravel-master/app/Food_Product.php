<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Food_Product extends Model
{
    protected $table='food_products';
    public $timestamps=false;

    protected $fillable=[
        'id',
        'title',
        'description',
        'category_ID'
    ];

    public function category()
    {
        return $this->belongsTo('App\Food_Category','category_ID');
    }

    public function food_products_ingredients()
    {
        return $this->hasMany('App\Food_Products_Ingredient','product_ID');
    }

    public function food_products_prices()
    {
        return $this->hasMany('App\Food_Products_Price','product_ID');
    }
}
